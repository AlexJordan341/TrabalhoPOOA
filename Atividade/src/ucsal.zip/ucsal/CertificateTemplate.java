package ucsal;

public class CertificateTemplate {

	 private String templateName;

	    public CertificateTemplate(String templateName) {
	        this.templateName = templateName;
	    }

	    public String getTemplateName() {
	        return templateName;
	    }
}
