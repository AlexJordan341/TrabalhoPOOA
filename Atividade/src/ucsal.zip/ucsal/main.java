package ucsal;

public class main {

	public static void main(String[] args) {
		 
		        CertificateGenerationComponent component = new CertificateGenerationComponent();
		        
		        // Adicionando templates de certificado
		        component.addTemplate(new CertificateTemplate("basic"));
		        component.addTemplate(new CertificateTemplate("advanced"));
		        
		        // Gerando certificados para um nome específico
		        component.generateCertificates("John big");
		        
		        // Encerrando o componente
		        component.shutdown();
		    }
}
